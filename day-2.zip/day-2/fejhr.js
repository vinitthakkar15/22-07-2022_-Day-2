var Example = prompt("Enter Your Name:- ");
document.write(Example);