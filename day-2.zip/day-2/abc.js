var Example = prompt("Enter Your value:- ");
document.write(Example);